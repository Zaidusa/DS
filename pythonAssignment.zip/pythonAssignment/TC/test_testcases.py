from POM.TIME_SERIES_DAILY_POM import Pom

class Testcases:
    def __init__(self):
        pass

    def test_Testcase1(self):
        timeinterval="1min"
        self.Tc=Pom()
        self.Tc.api(timeinterval)
T=Testcases()
T.test_Testcase1()