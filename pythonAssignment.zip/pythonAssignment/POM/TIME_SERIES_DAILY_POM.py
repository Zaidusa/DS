import requests
import time
class Pom:

    def __init__(self):
        pass

    def api (self, Interval):
        self.inter = Interval
        i = 0
        j = 2.88
        # converting 24 hrs to 1440 minutes to ensure total iterations of the day to 500.
        while (i < 1441):

            for k in range(5):
                url = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=IBM&outputsize=compact&interval=$inter&apikey=G4VJFBBQE9QYQ3UY'
                r = requests.get(url)
                print(r.status_code)
                time.sleep(12) # total 5 iterations for a minute, 60 min/12=5 so limiting range to 5

            i = i + j

        return r.status_code

